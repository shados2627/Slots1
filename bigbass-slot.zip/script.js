const symbols = ["🐟", "🎣", "💰", "🐠", "🧔‍♂️"];
const reelsContainer = document.getElementById("reels");
const spinButton = document.getElementById("spinButton");
const resultText = document.getElementById("resultText");

function createGrid() {
  reelsContainer.innerHTML = "";
  for (let i = 0; i < 15; i++) {
    const div = document.createElement("div");
    div.classList.add("symbol");
    div.textContent = "❓";
    reelsContainer.appendChild(div);
  }
}

function spinReels() {
  const results = [];
  const allDivs = document.querySelectorAll(".symbol");

  for (let i = 0; i < 15; i++) {
    const symbol = symbols[Math.floor(Math.random() * symbols.length)];
    allDivs[i].textContent = symbol;
    results.push(symbol);
  }

  checkWin(results);
}

function checkWin(results) {
  let win = false;
  for (let row = 0; row < 3; row++) {
    const start = row * 5;
    const rowSymbols = results.slice(start, start + 5);

    for (let i = 0; i <= 2; i++) {
      if (
        rowSymbols[i] === rowSymbols[i + 1] &&
        rowSymbols[i + 1] === rowSymbols[i + 2]
      ) {
        win = true;
      }
    }
  }

  resultText.textContent = win ? "🎉 You caught a Big Bass!" : "💨 No catch. Try again!";
}

createGrid();
spinButton.addEventListener("click", spinReels);
